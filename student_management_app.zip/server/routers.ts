import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  dashboard: router({
    getStats: protectedProcedure.query(async ({ ctx }) => ({
      totalStudents: 245,
      attendanceRate: 92,
      classesToday: 12,
      activeUsers: 38,
      myStudents: 45,
      avgAttendance: 89,
      pendingTasks: 3,
      myAttendance: 94,
      marksReceived: 8,
      classStrength: 42,
    })),
  }),

  students: router({
    list: protectedProcedure.query(async () => []),
  }),

  attendance: router({
    mark: protectedProcedure.mutation(async () => ({ success: true })),
    getReport: protectedProcedure.query(async () => ({ records: [], summary: {} })),
  }),

  marks: router({
    enter: protectedProcedure.mutation(async () => ({ success: true })),
    getReport: protectedProcedure.query(async () => ({ marks: [], summary: {} })),
  }),

  timetable: router({
    get: protectedProcedure.query(async () => []),
  }),
});

export type AppRouter = typeof appRouter;
