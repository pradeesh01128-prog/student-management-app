import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, attendance, marks, sections, students, subjects, timetable, teachers, classes } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Student queries
 */
export async function getStudentsByClass(classId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(students).where(eq(students.classId, classId));
}

export async function getStudentById(studentId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getStudentByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(students).where(eq(students.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Class queries
 */
export async function getAllClasses() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(classes);
}

export async function getClassById(classId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Section queries
 */
export async function getSectionsByClass(classId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sections).where(eq(sections.classId, classId));
}

/**
 * Subject queries
 */
export async function getAllSubjects() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(subjects);
}

/**
 * Attendance queries
 */
export async function getAttendanceByStudentAndDate(studentId: number, date: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(attendance).where(
    and(eq(attendance.studentId, studentId), eq(attendance.date, date as any))
  ).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAttendanceByClassAndDate(classId: number, date: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(attendance).where(
    and(eq(attendance.classId, classId), eq(attendance.date, date as any))
  );
}

/**
 * Marks queries
 */
export async function getMarksByStudentAndExam(studentId: number, examId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(marks).where(
    and(eq(marks.studentId, studentId), eq(marks.examId, examId))
  );
}

/**
 * Timetable queries
 */
export async function getTimetableByClassAndSection(classId: number, sectionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(timetable).where(
    and(eq(timetable.classId, classId), eq(timetable.sectionId, sectionId))
  );
}

/**
 * Teacher queries
 */
export async function getTeacherByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(teachers).where(eq(teachers.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}


