import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, date, time, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with role-based access control for admin, teacher, and student roles.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "teacher", "student"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Classes table - represents school classes/grades
 */
export const classes = mysqlTable("classes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  classCode: varchar("classCode", { length: 50 }).notNull().unique(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Class = typeof classes.$inferSelect;
export type InsertClass = typeof classes.$inferInsert;

/**
 * Sections table - represents sections within a class (e.g., A, B, C)
 */
export const sections = mysqlTable("sections", {
  id: int("id").autoincrement().primaryKey(),
  classId: int("classId").notNull(),
  name: varchar("name", { length: 50 }).notNull(),
  sectionCode: varchar("sectionCode", { length: 50 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Section = typeof sections.$inferSelect;
export type InsertSection = typeof sections.$inferInsert;

/**
 * Students table - student profiles with class and section assignment
 */
export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  rollNumber: varchar("rollNumber", { length: 50 }).notNull().unique(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  dateOfBirth: date("dateOfBirth"),
  classId: int("classId").notNull(),
  sectionId: int("sectionId").notNull(),
  address: text("address"),
  parentName: varchar("parentName", { length: 100 }),
  parentPhone: varchar("parentPhone", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

/**
 * Subjects table - school subjects
 */
export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  subjectCode: varchar("subjectCode", { length: 50 }).notNull().unique(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

/**
 * Attendance table - daily attendance records
 */
export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull(),
  classId: int("classId").notNull(),
  sectionId: int("sectionId").notNull(),
  date: date("date").notNull(),
  status: mysqlEnum("status", ["present", "absent", "late"]).notNull(),
  remarks: text("remarks"),
  markedBy: int("markedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = typeof attendance.$inferInsert;

/**
 * Exams table - exam/assessment records
 */
export const exams = mysqlTable("exams", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  examCode: varchar("examCode", { length: 50 }).notNull().unique(),
  classId: int("classId").notNull(),
  startDate: date("startDate").notNull(),
  endDate: date("endDate").notNull(),
  totalMarks: int("totalMarks").notNull().default(100),
  passingMarks: int("passingMarks").notNull().default(40),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Exam = typeof exams.$inferSelect;
export type InsertExam = typeof exams.$inferInsert;

/**
 * Marks table - student marks per subject per exam
 */
export const marks = mysqlTable("marks", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull(),
  examId: int("examId").notNull(),
  subjectId: int("subjectId").notNull(),
  marksObtained: decimal("marksObtained", { precision: 5, scale: 2 }).notNull(),
  totalMarks: int("totalMarks").notNull().default(100),
  grade: varchar("grade", { length: 5 }),
  remarks: text("remarks"),
  enteredBy: int("enteredBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Marks = typeof marks.$inferSelect;
export type InsertMarks = typeof marks.$inferInsert;

/**
 * Timetable table - weekly class schedules
 */
export const timetable = mysqlTable("timetable", {
  id: int("id").autoincrement().primaryKey(),
  classId: int("classId").notNull(),
  sectionId: int("sectionId").notNull(),
  dayOfWeek: mysqlEnum("dayOfWeek", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]).notNull(),
  startTime: time("startTime").notNull(),
  endTime: time("endTime").notNull(),
  subjectId: int("subjectId").notNull(),
  teacherId: int("teacherId"),
  roomNumber: varchar("roomNumber", { length: 50 }),
  remarks: text("remarks"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Timetable = typeof timetable.$inferSelect;
export type InsertTimetable = typeof timetable.$inferInsert;

/**
 * Teachers table - teacher profiles
 */
export const teachers = mysqlTable("teachers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  employeeId: varchar("employeeId", { length: 50 }).notNull().unique(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  qualification: varchar("qualification", { length: 200 }),
  specialization: varchar("specialization", { length: 200 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = typeof teachers.$inferInsert;

/**
 * Teacher Subjects - mapping of teachers to subjects they teach
 */
export const teacherSubjects = mysqlTable("teacherSubjects", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(),
  subjectId: int("subjectId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TeacherSubject = typeof teacherSubjects.$inferSelect;
export type InsertTeacherSubject = typeof teacherSubjects.$inferInsert;
