import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

const BACKGROUND_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663786698994/TVc5t2cXdAmN9m9GjrWCBZ/cartoon_school_background-oNZac2xPrHzwD7bswW34hA.webp";

export default function Home() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div 
        className="flex items-center justify-center min-h-screen bg-cover bg-center bg-no-repeat relative"
        style={{
          backgroundImage: `url(${BACKGROUND_URL})`,
        }}
      >
        <div className="absolute inset-0 bg-black/20"></div>
        <Card className="w-96 relative z-10 shadow-2xl border-2 border-white">
          <CardHeader className="bg-gradient-to-r from-blue-400 to-purple-400 text-white rounded-t-lg">
            <CardTitle className="text-center text-2xl">🎓 School Management System</CardTitle>
          </CardHeader>
          <CardContent className="pt-8">
            <p className="text-muted-foreground mb-6 text-center font-semibold">Welcome! Please log in to continue</p>
            <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-bold text-lg py-6" asChild>
              <a href="/api/oauth/login">Sign In</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat relative"
      style={{
        backgroundImage: `url(${BACKGROUND_URL})`,
      }}
    >
      <div className="absolute inset-0 bg-black/10"></div>
      <div className="relative z-10 space-y-8 p-8">
        <div className="bg-white/90 backdrop-blur-sm rounded-lg p-8 shadow-lg">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Welcome, {user.name}!</h1>
          <p className="text-gray-600 mt-2 text-lg">School Management Dashboard</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white/95 backdrop-blur-sm border-2 border-blue-200 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-blue-600">245</div>
              <p className="text-sm text-gray-600 font-semibold">Total Students</p>
            </CardContent>
          </Card>
          <Card className="bg-white/95 backdrop-blur-sm border-2 border-green-200 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-green-600">92%</div>
              <p className="text-sm text-gray-600 font-semibold">Attendance</p>
            </CardContent>
          </Card>
          <Card className="bg-white/95 backdrop-blur-sm border-2 border-orange-200 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-orange-600">12</div>
              <p className="text-sm text-gray-600 font-semibold">Classes Today</p>
            </CardContent>
          </Card>
          <Card className="bg-white/95 backdrop-blur-sm border-2 border-purple-200 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-purple-600">38</div>
              <p className="text-sm text-gray-600 font-semibold">Active Users</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
